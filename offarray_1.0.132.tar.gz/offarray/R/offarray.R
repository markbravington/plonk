# This is package offarray 

".onLoad" <-
function( libname, pkgname) {
### Generic dot-onLoad for mvbutils-created packages c.2021
  ## This part should only kick in when debugging C code with VSCode--
  ## should do nothing otherwise
  oa <- system.file( sprintf( 'R/load_%s_dll.R', pkgname),
      package=pkgname, lib.loc=libname)
  if( !nzchar( oa)) {
    oa <- system.file( sprintf( 'R/load_%s_dll.r', pkgname),
        package=pkgname, lib.loc=libname)
  }

  if( nzchar( oa)) {
    source( oa, local=TRUE)
  }

  # This should always happen; defines R wrappers for dot-calls
  # The function is defined by Cloaders_<pkgname>.R
  run_Cloaders <- get( sprintf( 'run_Cloaders_%s', pkgname))
  run_Cloaders()
}


"[.offarray" <-
function( x, ..., VECSUB, MATSUB, drop, NOOFF=FALSE) {
stopifnot( missing( drop)) # but still has to be in the arg list, I think!

  oc <- oldClass( x)

  # x[ i, j] -> x[ plus( i, Z), plus( j, Z)]
  # x[ i,] -> x[ plus( i, Z),]
  # Aplus <- function( x, y, i) if( is.logical( x)) x else { offsettle[i] <<- if( all( diff( x)==1L)) x[1L] else NA_integer_; x-y+1L }
  # environment( Aplus) <- environment()
  # Bplus <- function( x, y, i) Aplus( force( x), y, i, environment( sys.function()))
  ind <- match.call( expand.dots=F)$... # as.list( mc)[ -(1:2)]

  dn <- dimnames(x) # gonna need it

  if( !missing( VECSUB)) {
stopifnot( missing( MATSUB) && !length( ind)) # no other args allowed
    mc <- match.call()
    mc[[1L]] <- quote( `[`)
    mc[[2L]] <- substitute( unclass( .), list( .=mc[[2L]]))
    names( mc) <- NULL
return( as.vector( eval.parent( mc))) # strip all atts
  } else if( !missing( MATSUB)) {
stopifnot( !length( ind)) # no other args allowed
    if( is.list( MATSUB)) {
      is_char <- sapply( MATSUB, is.character)
stopifnot(
        length( MATSUB)==length( dim( x)),
        { lM <- lengths( MATSUB); all( lM==max( lM) | lM==1)},
        all( is_char | sapply( MATSUB , is.numeric))
      )

      charz <- which( is_char)
      if( length( charz)) { # then convert chars to numerics
        # offarray will always have dimnames (?) so this should be OK
stopifnot( all( charz %in% which( !sapply( dn, is.null))))

        MATSUB[ charz] <- FOR( charz, match( MATSUB[[.]], dn[[.]], NA))
      }

      # Convert to matrix
      MATSUB <- do.call( 'cbind', MATSUB)
    }


stopifnot( length( dim( MATSUB))==2 && ncol( MATSUB)==length( dim( x)))
    firsto <- x@offset
    firsto[ is.na( firsto)] <- 1
    MATSUB <- MATSUB - rep( firsto-1, each=nrow( MATSUB))
return( c( unclass( x)[ MATSUB]))
  } else {
    ##  Standard subscript

    if( !length( ind))
return( x)

    # l_missing <- sapply( ind, is.name); l_missing[ l_missing] <- !sapply( ind[ l_missing], nzchar)
    l_missing <- ismis( ind)

    nargl <- length( ind)
    naml <- names( ind)
    if( !is.null( naml) && any( nzchar( naml))) {
      drop <- (naml == 'SLICE') | (naml == 'DROP')
      if( any( nzchar( naml[ !drop])))
stop( "Don't understand index names... only SLICE (or, unpreferably but synonymously) DROP allowed")
    } else {
      drop <- rep( FALSE, nargl)
    }

    attx <- attributes( x)
    offsettle <- attx$offset # x@offset
    offsettle[ lengths( dn, FALSE)>0] <- NA_integer_

    addoff <- !l_missing & !is.na( offsettle)

    mc <- match.call() # easier to call again, than to muck about with ind
    mc$drop <- FALSE
    mc$NOOFF <- NULL

    for( i in which( addoff)) {
      mc[[ 2L+i]] <- substitute( plus( ind, off, i, e),
          list( plus=Aplus, ind=mc[[2L+i]], off=offsettle[ i], i=i, e=environment()))
    }

    mc[[2L]] <- substitute( unclass( .), list( .=mc[[2L]]))
    mc[[1]] <- `[` # should not be needed except when debugging deliberate calls to 'subset.offarray'
    res <- eval.parent( mc)

    drop <- drop & (dim( res)==1L) # did have: | no_offset
    if( any( drop)) {
      if( all( drop)) {
return( structure( as.vector( res), class=oc %except% 'offarray'))
      }

      offsettle <- offsettle[ !drop] # works even if NULL!
      dimnam <- dimnames( res)[ !drop]
      dim( res) <- dim( res)[ !drop]
      dimnames( res) <- dimnam
    }

    # Check whether any offsets have been set to NA (implying non-consec)
    if( !NOOFF && all( !xor( is.na( attx$offset[ !drop]), is.na( offsettle)))) {
      attr( res, 'offset') <- offsettle
      oldClass( res) <- oc
    } else { # STANDARD ARRAY
      if( !NOOFF) { # forced to lose offsets, but
warning( "Can't keep offarrayness, but NOOFF wasn't set FALSE")
      }
    }
  } # standard subscript

res
}


"[<-.offarray" <-
function (x, ..., VECSUB, MATSUB, value) {
  ind <- match.call( expand.dots=F)$...
#  cat( 'Call:\n')
#  print( ind)

  if( !missing( VECSUB)) {
    if( !missing( MATSUB) || length( ind))
stop( "Can't mix VECSUB replacement with other types")
    mc <- match.call()
    mc[[2L]] <- substitute( unclass( .), list( .=mc[[2L]])) # probably '*tmp*'
    mc[[1]] <- `[<-`
    mcc <- as.call( list( `class<-`, mc, 'offarray'))
return( eval.parent( mcc))
  }

  attx <- attributes( x)
  dn <- attx$dimnames
  offsettle <- attx$offset # x@offset
  offsettle[ lengths( dn, FALSE)>0] <- 1L
  offsettle[ is.na( offsettle)] <- 1L

  if( !missing( MATSUB)) {
    if( length( ind))
stop( "Can't mix MATSUB replacement with other types")

    if( is.list( MATSUB)) {
      is_char <- sapply( MATSUB, is.character)
stopifnot(
        length( MATSUB)==length( dim( x)),
        { lM <- lengths( MATSUB); all( lM==max( lM) | lM==1)},
        all( is_char | sapply( MATSUB , is.numeric))
      )

      charz <- which( is_char)
      if( length( charz)) { # then convert chars to numerics
        # offarray will always have dimnames (?) so this should be OK
stopifnot( all( charz) %in% which( !sapply( dn, is.null)))

        MATSUB[ charz] <- FOR( charz, match( MATSUB[[.]], dn[[.]], NA))
      }

      # Convert to matrix
      MATSUB <- do.call( 'cbind', MATSUB)
    }


    if( !is.matrix( MATSUB))
stop( "Matrix replacement requires a matrix...")

    # Should avoid extra copy!!
    x <- structure( c( x), dim=attx$dim)
    x[1 + sweep( MATSUB, 2L, offsettle)] <- value
    attributes(x) <- attx
return(x)
  }

  # else { # normal "cuboid"

  mc <- match.call()
#  environment( temp_scrunge) <- environment()
#  mc <- temp_scrunge()

  l_missing <- ismis( ind)
  if( length( ind) > 1L || !l_missing) {
    if( length( ind) != length( dim( x)))
  stop( "Wrong number of indices")

    addoff <- !l_missing & (offsettle != 1L)

    for( i in which( addoff)) {
      mc[[ 2L+i]] <- substitute( plus( ind, ii),
          list( plus=Arepplus, ind=mc[[2L+i]], ii=offsettle[ i]))
    }
  }

  mc[[2L]] <- substitute( unclass( .), list( .=mc[[2L]])) # probably '*tmp*'
  mc[[1]] <- `[<-`
#  mcc <- as.call( list( `class<-`, mc, 'offarray'))
#  cat( 'About to eval:\n')
#  print( mcc)
# eval.parent( mcc)

  # Erratic problems with '*tmp*' not being found (?already deleted by a gc step?)
  # Not reprod between machines apparently
  # Maybe the class-assign is too much in one step
  # Let's try this...
  #  startemp <- eval.parent( mc)
  
  # Actually, even that could risk some enviro woe if '*tmp*' lands on top of an existing one
  # Maybe this is safe...
  eee <- new.env( parent=parent.frame())
  startemp <- eval( mc, eee) # almost in parent.frame() but safer..?
  
  oldClass( startemp) <- 'offarray'
return( startemp)
}


"aperm.offarray" <-
function( a, perm){
  offo <- a@offset
  a <- NextMethod( a)
  a@offset <- offo[ perm]
  class( a) <- 'offarray'
return( a)
}


"as.array.offarray" <-
function (x, ...) {
  dn <- dimnames( x)
  if( is.null( dn)) { # shouldn't be...
    dn <- rep( list( NULL), length( dim( x)))
  }
  numdim <- sapply( dn, is.null)
  dn[ numdim] <- FOR( which( numdim), x@offset[.] + 0 %upto% (dim(x)[.]-1))
  x <- unclass(x)
  x@offset <- NULL
  dimnames( x) <- dn

  NextMethod(x)
}


"as.data.frame.offarray" <-
function( x, row.names=NULL, optional=NULL, add_names=NULL,
    name_of_response='response', ...) {
#####
  ## 'optional' and 'row.names' needed for compatibility with generic,
  # but both are ignored
  d <- dim( x)
  nd <- length( d)
  dn <- dimnames( x)
  if( is.null( dn)) {
    dn <- structure( vector( 'list', nd), names='D' %&% seq_along( dim (x)))
  }

  ndna <- add_names
  if( is.null( ndna)) {
    ndna <- names( dn)
  } else {
stopifnot( length( ndna)==nd) # ie bad add_names
  }

  if( is.null( ndna)) {
    ndna <- 'D' %&% seq_along( dim (x)) # else unnamed dimnames could be obliterated in next step
  }

  if( name_of_response %in% ndna) {
stop( "name_of_response must differ from names( dimnames))")
  }

  for(i in which( sapply( dn, is.null))) {
    dn[[ i]] <- x@offset[ i]-1 + (1:d[ i])
  }
  df <- do.call( 'expand.grid', c( dn, list( KEEP.OUT.ATTRS=FALSE, stringsAsFactors=FALSE)))
  df[[ name_of_response]] <- as.vector( x)
return( df)
}


"autoloop" <-
function( expr, ...) {
  mc <- match.call( expand.dots=TRUE)
  mc$expr <- NULL
  subs <- names( mc) %except% ''

  mc[[1]] <- quote( expand.grid)
  mc$stringsAsFactors <- FALSE
  mc$KEEP.OUT.ATTRS <- FALSE
  eg <- eval.parent( mc)

  dn <- structure( vector( 'list', length( eg)), names=names( eg))
  charz <- which( sapply( eg, is.character))
  if( length( charz)) {
    dn[ charz] <- list(...)[ charz]
    eg[ charz] <- FOR( charz, match( eg[[.]], dn[[.]]))
  }

  subex <- substitute( expr)

  # Mod to handle lookups eg lookup( { ... myar[ X, Y] ...}, X=..., Y=...})
  # Operationally, must replace with myar[ MATSUB=cbind( X, Y)]
  # Has to be fast, ie no manual traversing the "parse tree", hence 'substitute'
  # Actually replace by offarray:::sneaky_subset( myar, X, Y) which duz the biz on the fly
  # CRANiacs will moan about triple-colon
  # so when it comes to "submission" time--- ie when we have to submit to their little whims---
  # then hardwire the function directly like this
  # subex1 <- do.call( 'substitute', list( subex, list( '['=asNamespace( 'offarray')$sneaky_subset)))
  # but the form below allows debugging

  subex1 <- do.call( 'substitute', list( subex, list( '['=quote( offarray:::sneaky_subset))))
  outcomes <- eval( subex1, envir=eg, enclos=parent.frame())

  # Slightly lazy; could eval each dot-arg and call range on that unique set of values
  # but it's possibly quicker and certainly easier to let R do the work on replicated sets

  ranges <- sapply( eg, range)
  ar1 <- offarray( 0, first=ranges[1,], last=ranges[2,], dimnames=dn)

  egm <- as.matrix( eg)

  if( outcomes %is.not.a% 'list') { # single value
    ar1[ MATSUB=egm] <- outcomes
return( ar1)
  } else {
    nouts <- names( outcomes)
    if( is.null( nouts) || !all( nzchar( nouts))) {
stop( "List of returnees must be fully named")
    }
    ar <- list()
    for( iout in nouts) {
      ar1[ MATSUB=egm] <- outcomes[[ iout]]
      ar[[ iout]] <- ar1
    }
return( ar)
  }
}


"dimrange" <-
function( x, which=rep( TRUE, length( dim( x)))) {
stopifnot( x %is.an% 'offarray')
  cbind( firstel( x), lastel( x))[ which,,drop=FALSE]
}


"dimseq" <-
function( x, which=NULL, drop=TRUE) {
stopifnot( x %is.an% 'offarray')

  if( is.null( which)) {
    which <- seq_along( dim( x))
  }

  dn <- dimnames( x)
  if( is.null( dn)) {
    dn <- rep( list( NULL), length( dim( x)))
  }

  listo <- FOR( which,
    if( !is.null( dn[[.]])) dn[[.]] else (firstel( x, .) %upto% lastel( x, .))

    )
  if( (length( which)==1) && drop) {
return( listo[[1]])
  } else {
return( listo)
  }
}


"firstel" <-
function( x, which=NULL) {
  firstel <- x@offset
  if( is.null( firstel)) {
    firstel <- 1L + 0L*dim( x)
    if( !length( firstel)) { # pure vector
      firstel <- 1L
    }
  }
  firstel[ is.na( firstel)] <- 1L # if has dimname, does not need offset
  if( !is.null( nd <- names( dimnames( x)))) {
    names( firstel) <- nd
  }

  if( !is.null( which)) {
    firstel <- unname( firstel[ which])
  }
return( firstel)
}


"head.offarray" <-
function( x, n=6L, ...) {
  # Bloody 'NextMethod' behaves as incomprehensibly as usual, so...
  thing <- head( unclass( x), n, ...)

  if( length( dim( x)) == 1) {
    thing <- offarray( thing, first=firstel( x), dim=length( thing))
  } else if( length( dim( x)) == 2) {
    thing <- offarray( thing, first=firstel( x), dim=dim( thing))
  } # else an array, which get brutally vectored

return( thing)
}


"lastel" <-
function( x, which=NULL) {
  firstel <- firstel( x)
  lastel <- unname( dim( x)) + firstel - 1L
  if( !length( lastel)) {
    lastel <- length( x)
  }
  if( !is.null( which)) {
    lastel <- unname( lastel[ which])
  }
return( lastel)
}


"offarray" <-
function( x, ...)
  UseMethod( 'offarray', x)


"offarray.data.frame" <-
function( x, data.col) {
## Sorry about the dot in data.col--- it's for consistency with other similar
# functions of mine (in non-public packages)
stopifnot(
    !missing( data.col),
    is.character( data.col),
    length( data.col) == 1,
    data.col %in% names( x)
  )

  is_factor <- sapply( x, is.factor)
  x[ is_factor] <- lapply( x[ is_factor], as.character)
  dimcols <- names( x) %except% data.col
  ndims <- length( dimcols)
  is_int <- do.on( dimcols, is.numeric( x[[.]]) && all( my.all.equal( x[[.]], round( x[[.]]))))
  nels <- do.on( dimcols, length( unique( x[[.]])))
  int_ranges <- do.on( dimcols[ is_int], range( x[[.]]))
  char_sets <- FOR( dimcols[ !is_int], sort( unique( as.character( x[[.]])), method='radix'))
  # ... radix sort (only) is consistent across locales

  dnl <- structure( rep( list( NULL), ndims), names=dimcols)
  dnl[ !is_int] <- char_sets

  firsts <- rep( 1L, ndims)
  firsts[ is_int] <- int_ranges[ 1,]

  lasts <- nels
  lasts[ is_int] <- int_ranges[ 2,]

  output <- offarray( x[[ data.col]][1], first=firsts, last=lasts, dimnames=dnl)
  output[] <- NA # correct mode

  # Now put elements of x[[data.col]] into correct spots in offarray
  # NB if multiple assignments to same element--- last one will be kept
  xlu <- matrix( 1:nrow( x), nrow=nrow( x), ncol=ndims, dimnames=list( NULL, dimcols))
  for( i in dimcols[ is_int]) {
    xlu[ ,i] <- x[[i]]
  }
  for( i in dimcols[ !is_int]) {
    xlu[ ,i] <- match( as.character( x[[i]]), char_sets[[i]])
  }

  output[ MATSUB=xlu] <- x[[ data.col]]
return( output)
}


"offarray.default" <-
function( x = NA,
    first = rep( 1L, length( dim)),
    last = first + dim - 1L,
    dim = NULL,
    dimnames = NULL) {
###########################

  oc <- oldClass( x)

  if( missing( dim)) {
    dim <- NULL
  }

  # Sanity checks: first/last/dim must if named all have same names
  ninds <- list( names( first), names( last), names( dim))
  wi <- which( !sapply( ninds, is.null))
  if( length( wi)) {
    dimbo <- matrix( unlist( ninds[ wi]), ncol=length( wi))

    # Check for contradictory names...
    namdim <- apply( dimbo, 1, function( x) tail( sort( x), 1))
stopifnot( all( (dimbo==namdim) | (dimbo=='')))
  } else {
    namdim <- NULL
  }

  if( is.null( dim)) {
    dim <- last - first + 1L # will be auto named
  } else {
    names( dim) <- namdim # make sure
  }

  robj <- array( data = x, dim = dim, dimnames = dimnames)

  # If explicit elts for one dimname, offset is not used, so set to NA
  # Often useful to name the dimnames, regardless
  # names( dimnames) should dominate any of the others
  if( !is.null( dimnames)) {
    if( !is.null( namdim)) {
      if( !is.null( ndn <- names( dimnames))) {
        # Blatant contradiction ?
        nz1 <- nzchar( namdim)
        nz2 <- nzchar( ndn)
stopifnot( all( (ndn[ nz1 & nz2] == namdim[ nz1 & nz2])))
        namdim[ !nz1] <- ndn[ !nz1] # supply those originally in dimnames but not in namdim
      }

      names( dimnames) <- namdim
    } else { # if no namdim
      namdim <- names( dimnames)
    }

    no_offset_since_named <- !sapply( dimnames, is.null)
    fnosn <- first[ no_offset_since_named]
    if( any(  !is.na( fnosn) & fnosn != 1))
stop( "Can't have none-1 starts for dimensions with names")

    first[ no_offset_since_named] <- NA
  } else if( !is.null( namdim)) {
    # empty named list
    dimnames <- rep( list( NULL), length( dim))
    names( dimnames) <- namdim
  }

  if( !is.null( namdim)) {
    dim( robj) <- structure( unname( dim( robj)), names=namdim)
  }

  dimnames( robj) <- dimnames # maybe NULL
  robj@offset <- as.integer( unname( first))
  oldClass(robj) <- c( "offarray", oc %except% c( 'matrix', 'array', 'offarray'))

return( robj)
}


"offarray.table" <-
function( x, template=NULL) {
  dranges <- suppressWarnings( lapply( dimnames( x), as.integer))
  is_char <- is.na( sapply( dranges, sum))
  dranges[ is_char] <- FOR( dranges[ is_char], c( 1, length( .)))

  if( is.null( template)) { # make it up from dims of table
    off <- offarray( 0, first=sapply( dranges, min), last=sapply( dranges, max))

    if( !is.null( namdim <- names( dimnames( x)))) {
      dimnames( off) <- structure( rep( list( NULL), length( namdim)), names=namdim)
    }
    if( any( is_char)) {
      dimnames( off)[ is_char] <- dimnames( x)[ is_char]
    }

    off@offset[ is_char] <- NA_integer_

  } else {
    off <- 0*template
  }

  # Populate the new structure, based on the table
  # Allows for blanks--- ie indices in the template that don't appear in the table
  # ... and reordering of char indices between template and table

  dranges[ is_char] <- dimnames( x)[ is_char] # so that insertion happens "in the right order"
  cc <- as.call( c( list( as.name( '['), as.name( 'off')), dranges))
  ccc <- substitute( xx <- x, list( xx=cc))
  eval( ccc)
return( off)
}


"print.offarray" <-
function (x, ...) {
#######
# taken directly from 'print.Oarray', except for 'x@offset' below
    d <- dim(x)
    dn <- dimnames(x)
    if (is.null(dn)) 
        dn <- vector("list", length(d))
    offset <- x@offset
    offset[ is.na( offset)] <- 1L # new
    oc <- oldClass( x) %except% c( 'array', 'offarray', 'matrix')
    x <- as.array(x)
    for (i in seq(along = dn)) {
      if (is.null(dn[[i]])) { 
        dn[[i]] <- 0 %upto% (d[i] - 1) + offset[i] # upto ICO 0-length
        dn[[i]] <- format( dn[[i]])
        if (i <= 2) {
            dn[[i]] <- sprintf( '[%s%s%s]',
                if( i>1) ',' else '',
                dn[[i]],
                if( i==1 && length( dn) > 1) ',' else '')
        }
      }
    }
    
    if( length( oc)) {
      class( x) <- c( oldClass( x), oc)
    }
    
    dimnames(x) <- dn
    NextMethod("print")
}


"slice_atts" <-
function( x, which, ..., drop=FALSE)
  UseMethod( 'slice_atts')


"slice_atts.default" <-
function( x, which, ..., drop=FALSE) {
  atts <- list( dimnames = dimnames( x)[ which], dim=dim( x)[ which])
  if( drop || !length( atts$dim)) {
    if( any( dropme <- atts$dim==1)) {
      atts <- c( atts[[1]][ !dropme], atts[[2]][ !dropme])
    }
    if( length( atts$dim) <= 1) {
      nam <- atts$dimnames[[1]]
      if( !is.null( nam)) {
        atts <- list( names=nam)
      } else {
        atts <- list()
      }
    }
  }
return( atts)
}


"slice_atts.offarray" <-
function( x, which, ..., drop=FALSE) {
  offo <- x@offset
  odims <- dim( x)
  odrop <- drop
  drop <- FALSE
  atts <- NextMethod( 'slice_atts')
  atts$offset <- offo[ which]
  if( odrop) {
    if( any( dropme <- (atts$dim==1 & atts$offset==1))) {
      atts <- c( atts[[1]][ !dropme], atts[[2]][ !dropme], atts[[3]][ !dropme])
    }

    # Always keep it as an offarray, so firstel() etc work
    if( (length( atts$dim == 1) & my.all.equal( atts$offset, 1))) {
      nam <- atts$dimnames[[1]]
      if( !is.null( nam)) {
        atts <- list( names=nam, offset=1L)
      } else {
        atts <- list( offset=1L)
      }
    }
  }

  if( length( atts$offset)) {
    atts$class <- 'offarray'
  } else {
    atts <- list() # contracted over all dimensions
  }

return( atts)
}


"slindoff" <-
function( offa, MARGIN) {
  if( is.character( MARGIN)) {
    IMARGIN <- match( MARGIN, names( dimnames( offa)), 0)
    if( !IMARGIN) {
stop( sprintf( 'No dimension named "%s"', MARGIN))
    }
    MARGIN <- IMARGIN
  }
  y <- firstel( offa, MARGIN) + slice.index( offa, MARGIN) - 1L
  attributes( y) <- attributes( offa)[ cq( class, dim, dimnames, offset)]
return( y)
}


"sneaky_subset" <-
function( x, ...) {
    # mc <- match.call( expand.dots=FALSE)
    # sigh... R is stuffing around making pairlists where it didn't use to
    # so...

    mc <- mc2 <- match.call( expand.dots=TRUE)
    if( nargs()==2) {
      mc[[1]] <- as.name( '[')
      if( x %is.an% 'offarray') {
        mc$NOOFF <- TRUE
      }
return( eval.parent( mc))
    }


    mc2 <- mc2[-2]
    if( x %is.an% 'offarray') {
      mc2[[1]] <- quote( list)
      # ... used to have quote( cbind), but that will coerce to character
      # ... whereas the normal '[.offarray' will unpack list correctly
      # ... MATSUB=list() option did not exist when this was first written

      callo <- call( '[', mc$x, MATSUB=mc2)
    } else {
      mc2[[ 1]] <- quote( cbind)
      callo <- call( '[', mc$x, mc2)
    }

    eval.parent( callo)
  }


"str.offarray" <-
function( object, ...) {
  cat( strguts.offarray( object), '\n')
invisible()
}


"strguts.offarray" <-
function( x) {
  spr <- sprintf( '%i:%i', firstel( x), lastel( x))
  sprch <- sprintf( 'ch(%i)', dim( x))
  is.ch <- lengths( dimnames( x)) > 0
  spr[ is.ch] <- sprch[ is.ch]

  if( !is.null( ndn <- names( dimnames( x)))) {
    spr <- sprintf( '%s=%s', ndn, spr)
  }
return( sprintf( 'offarray: %s', paste( sprintf( '(%s)', spr), collapse='*')))
}


"subset.offarray" <-
function (x, ..., VECSUB, MATSUB, drop) {
stopifnot( missing( drop)) # but still has to be in the arg list, I think!

  # x[ i, j] -> x[ plus( i, Z), plus( j, Z)]
  # x[ i,] -> x[ plus( i, Z),]
  # Aplus <- function( x, y, i) if( is.logical( x)) x else { offsettle[i] <<- if( all( diff( x)==1L)) x[1L] else NA_integer_; x-y+1L }
  # environment( Aplus) <- environment()
  # Bplus <- function( x, y, i) Aplus( force( x), y, i, environment( sys.function()))
  ind <- match.call( expand.dots=F)$... # as.list( mc)[ -(1:2)]
  
  if( !missing( VECSUB)) {
stopifnot( missing( MATSUB) && !length( ind)) # no other args allowed
    stop( 'VECSUB: NYI')
  } else if( !missing( MATSUB)) {
stopifnot( !length( ind)) # no other args allowed
    stop( 'MATSUB: NYI')
  } else { # standard subscript
    if( !length( ind))
return( x)

    # l_missing <- sapply( ind, is.name); l_missing[ l_missing] <- !sapply( ind[ l_missing], nzchar)  
    l_missing <- ismis( ind) 

    nargl <- length( ind)
    naml <- names( ind)
    if( !is.null( naml) && any( nzchar( naml))) {
      drop <- naml == 'DROP'
      if( any( nzchar( naml[ !drop])))
stop( "Don't understand index names... only DROP allowed")     
    } else {
      drop <- rep( FALSE, nargl)
    }

    attx <- attributes( x)
    dn <- attx$dimnames
    offsettle <- attx$offset # x@offset
    offsettle[ lengths( dn, FALSE)>0] <- 1L
    offsettle[ is.na( offsettle)] <- 1L
    lose.offsets <- all( offsettle==1L)
    
    addoff <- !l_missing & (offsettle != 1L)

    mc <- match.call() # easier to call again, than to muck about with ind
    mc$drop <- FALSE

    for( i in which( addoff)) {
      # mc[[ 2L+i]] <- substitute( plus( ind, off, i), list( plus=Bplus, ind=mc[[2L+i]], off=offsettle[ i], i=i))
      mc[[ 2L+i]] <- substitute( plus( ind, off, i, e), 
          list( plus=Aplus, ind=mc[[2L+i]], off=offsettle[ i], i=i, e=environment()))
    }

    # x@offset <- NULL
    mc[[2L]] <- substitute( unclass( .), list( .=mc[[2L]]))
    mc[[1]] <- `[` # should not be needed except when debugging deliberate calls to 'subset.offarray'
    res <- eval.parent( mc)
    
    drop <- drop & (dim( res)==1L) # did have: | no_offset
    if( any( drop)) {
      if( all( drop)) {
return( as.vector( res))
      }

      offsettle <- offsettle[ !drop]
      dimnam <- dimnames( res)[ !drop]
      dim( res) <- dim( res)[ !drop]
      dimnames( res) <- dimnam
      lose.offsets <- all( offsettle==1L)
    }    
    
    if( !lose.offsets) { 
      attr( res, 'offset') <- offsettle
      # res@offset <- offsettle
      oldClass( res) <- 'offarray'
    }
  } # standard subscript

res
}


"sumover" <-
function( x, mm, drop=FALSE) {
  # Also works on offarray objects, thx2 generic slice_atts

  ndim <- length( dim( x))
stopifnot( ndim>0)
  if( is.character( mm)) {
    mm <- match( mm, names( dimnames( x)), 0)
  }
stopifnot( all( mm>0 & mm<=ndim))

  smm <- sort( mm)
  ndimsum <- length( mm)
  dims <- dim( x)

  bedims <- 1 %upto% ndimsum
  endims <- seq( to=ndim, length=ndimsum)

  # rowSums, colSums, or aperm required ?
  if( my.all.equal( smm, bedims)) {
    z <- x # no copy
    y <- .colSums( z,
        prod( dims[ bedims]),
        prod( dims[ -bedims]))

  } else {
    if( my.all.equal( smm, endims)) {
      z <- x
    } else {
      z <- aperm( x, c( seq_along( dims) %except% smm, smm))
      dims <- dim( z)
      smm <- endims
    }
    y <- .rowSums( z,
        prod( dims[ -endims]),
        prod( dims[ endims]))
  }

  attributes( y) <- slice_atts( z, -smm, drop=drop)

  # ?drop-stuff goes here?

return( y)
}


"t.offarray" <-
function( x){
  offo <- x@offset
  x <- NextMethod( x)
  x@offset <- rev( offo)
  class( x) <-  'offarray'
return( x)
}


"tail.offarray" <-
function( x, n=6L, ...) {
  # Bloody 'NextMethod' behaves as incomprehensibly as usual, so...
  thing <- tail( unclass( x), n, ...)

  if( length( dim( x)) == 1) {
    thing <- offarray( thing, first=lastel( x)-length( thing)+1, dim=length( thing))
  } else if( length( dim( x)) == 2) {
    thing <- offarray( thing, first=lastel( x)-dim( thing)+1, dim=dim( thing))
  } # else an array, which get brutally vectored

return( thing)
}

# MVB's workaround for futile CRAN 'no visible blah' check:
globalVariables( package="offarray",
  names=c( ".Traceback"
    ,"oa"
    ,"pkgname"
    ,"libname"
    ,"run_Cloaders"
    ,"oc"
    ,"x"
    ,"ind"
    ,"..."
    ,"dn"
    ,"VECSUB"
    ,"MATSUB"
    ,"mc"
    ,"."
    ,"is_char"
    ,"lM"
    ,"charz"
    ,"firsto"
    ,"offset"
    ,"l_missing"
    ,"ismis"
    ,"nargl"
    ,"naml"
    ,"attx"
    ,"offsettle"
    ,"addoff"
    ,"NOOFF"
    ,"i"
    ,"plus"
    ,"off"
    ,"e"
    ,"Aplus"
    ,"res"
    ,"dimnam"
    ,"mcc"
    ,"value"
    ,"ii"
    ,"Arepplus"
    ,"eee"
    ,"startemp"
    ,"offo"
    ,"a"
    ,"perm"
    ,"numdim"
    ,"d"
    ,"nd"
    ,"ndna"
    ,"add_names"
    ,"name_of_response"
    ,"df"
    ,"expr"
    ,"subs"
    ,"stringsAsFactors"
    ,"KEEP.OUT.ATTRS"
    ,"eg"
    ,"subex"
    ,"subex1"
    ,"outcomes"
    ,"ranges"
    ,"ar1"
    ,"egm"
    ,"nouts"
    ,"ar"
    ,"iout"
    ,"listo"
    ,"thing"
    ,"n"
    ,"data.col"
    ,"is_factor"
    ,"dimcols"
    ,"ndims"
    ,"is_int"
    ,"nels"
    ,"int_ranges"
    ,"char_sets"
    ,"dnl"
    ,"firsts"
    ,"lasts"
    ,"output"
    ,"xlu"
    ,"ninds"
    ,"first"
    ,"last"
    ,"wi"
    ,"dimbo"
    ,"namdim"
    ,"robj"
    ,"ndn"
    ,"nz1"
    ,"nz2"
    ,"no_offset_since_named"
    ,"fnosn"
    ,"dranges"
    ,"template"
    ,"cc"
    ,"ccc"
    ,"xx"
    ,"atts"
    ,"dropme"
    ,"nam"
    ,"odims"
    ,"odrop"
    ,"MARGIN"
    ,"IMARGIN"
    ,"offa"
    ,"y"
    ,"mc2"
    ,"callo"
    ,"object"
    ,"spr"
    ,"sprch"
    ,"is.ch"
    ,"lose.offsets"
    ,"ndim"
    ,"mm"
    ,"smm"
    ,"ndimsum"
    ,"dims"
    ,"bedims"
    ,"endims"
    ,"z"
))

