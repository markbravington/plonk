#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
LogicalVector ismis( Pairlist dots) {
  int nargl = dots. size();
  LogicalVector ismis( nargl);
  for( int i=0; i<nargl; i++) {
    ismis[ i] =  dots[i] == R_MissingArg;
  }
  return ismis;
}

//   Aplus <- function( x, y, i) if( is.logical( x)) x else { offsettle[i] <<- if( all( diff( x)==1L)) x[1L] else NA_integer_; x-y+1L }

// [[Rcpp::export]]
RObject Aplus( RObject x, int y, int ii, Environment e) {
  if( (TYPEOF( x) == LGLSXP) | (LENGTH(x)==0) ) {
return x;
  }

  IntegerVector ix = clone( IntegerVector( x));
  int lenx = ix.size();
  int firsto = ix[ 0];
  ix = ix - y + 1;

  // Also OOR checks...
  bool conseq = true;
  int nextcon = ix[0];
  if( (nextcon <= 0) | IntegerVector::is_na( nextcon)) {
throw std::range_error( "Naughty subset index");
  } // too-large throws auto in R

  for( int i=1; (i<lenx) & conseq; i++) {
    if( (ix[i] <=0) | IntegerVector::is_na( ix[ i])) {
throw std::range_error( "Naughty subset index");
    } // too-large throws auto in R
    nextcon++;
    // Rcpp::Rcout << "nextcon " << nextcon << " idx " << ix[i] << std::endl;
    conseq = ix[i] == nextcon;
  }

  // Direct write-access!
  RObject eoff = e[ "offsettle"];
  bool offisint = TYPEOF( eoff) == INTSXP; // can we do in-place mod? In theory, yes...
  IntegerVector offsettle = IntegerVector( e[ "offsettle"]);
  offsettle[ ii-1] = conseq ? firsto : NA_INTEGER;
  if( !offisint) {
    e.assign( "offsettle", offsettle);
  }

  return ix;
}

// [[Rcpp::export]]
RObject Arepplus( RObject x, int y) {
  if( (TYPEOF( x) == LGLSXP) | (LENGTH(x)==0) ) {
return x;
  }

  IntegerVector ix = clone( IntegerVector( x));
  ix = ix - y + 1;
  int lenx = ix.size();

  for( int i=0; i<lenx; i++) {
    if( (ix[i] <=0) | IntegerVector::is_na( ix[ i])) {
throw std::range_error( "Naughty replacement index");
    } // too-large throws auto in R
  }

  return ix;
}

